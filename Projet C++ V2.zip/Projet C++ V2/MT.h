#pragma once
#include <random>

class MT {
private:
    std::mt19937 _mt;
    MT() : _mt(std::random_device{}()) {}

    // M�thodes internes d'instance
    double rand_unif_impl() { return std::uniform_real_distribution<double>(0.0, 1.0)(_mt); }
    double rand_norm_impl() { return std::normal_distribution<double>(0.0, 1.0)(_mt); }

public:
    // Singleton
    static MT& getInstance() {
        static MT instance;
        return instance;
    }

    // M�thodes statiques publiques
    static double rand_unif() { return getInstance().rand_unif_impl(); }
    static double rand_norm() { return getInstance().rand_norm_impl(); }

    MT(const MT&) = delete;
    MT& operator=(const MT&) = delete;
};
