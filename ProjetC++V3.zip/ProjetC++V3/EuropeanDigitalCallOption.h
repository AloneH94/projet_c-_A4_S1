#pragma once
#include "EuropeanVanillaOption.h"

class EuropeanDigitalCallOption : public EuropeanVanillaOption {
public:
    EuropeanDigitalCallOption(double expiry, double strike) : EuropeanVanillaOption(expiry, strike) {}
    double payoff(double spot) const override { return (spot >= getStrike()) ? 1.0 : 0.0; }
    optionType GetOptionType() const override { return optionType::Call; }
};