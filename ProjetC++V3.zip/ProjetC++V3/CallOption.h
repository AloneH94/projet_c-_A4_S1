#pragma once
#include "EuropeanVanillaOption.h"
#include <algorithm>

class CallOption : public EuropeanVanillaOption {
public:
    CallOption(double expiry, double strike) : EuropeanVanillaOption(expiry, strike) {}
    double payoff(double spot) const override { return std::max(spot - getStrike(), 0.0); }
    optionType GetOptionType() const override { return optionType::Call; }
};