﻿#pragma once
#include "Option.h"

class EuropeanVanillaOption : public Option {
private:  
    double _strike;

public:
    enum class optionType { Call, Put }; 

    EuropeanVanillaOption(double expiry, double strike) : Option(expiry), _strike(strike) {
        if (strike < 0.0) throw std::invalid_argument("Strike must be non-negative");
    }

    virtual optionType GetOptionType() const = 0; 
    double getStrike() const { return _strike; }

    friend class BlackScholesPricer;
    friend class CRRPricer;
};