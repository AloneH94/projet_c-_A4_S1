#pragma once
#include "EuropeanVanillaOption.h"

class EuropeanDigitalPutOption : public EuropeanVanillaOption {
public:
    EuropeanDigitalPutOption(double expiry, double strike) : EuropeanVanillaOption(expiry, strike) {}
    double payoff(double spot) const override { return (spot <= getStrike()) ? 1.0 : 0.0; }
    optionType GetOptionType() const override { return optionType::Put; }
};