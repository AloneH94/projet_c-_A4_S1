#pragma once
#include "EuropeanVanillaOption.h"
#include <algorithm>

class PutOption : public EuropeanVanillaOption {
public:
    PutOption(double expiry, double strike) : EuropeanVanillaOption(expiry, strike) {}
    double payoff(double spot) const override { return std::max(getStrike() - spot, 0.0); }
    optionType GetOptionType() const override { return optionType::Put; }
};