#pragma once
#include "EuropeanVanillaOption.h"
#include "EuropeanDigitalCallOption.h"
#include "EuropeanDigitalPutOption.h"
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

class BlackScholesPricer {
private:
    EuropeanVanillaOption* _option;
    double _S, _r, _sigma;

    // Fonction de r�partition normale
    double norm_cdf(double x) const {
        return 0.5 * std::erfc(-x / std::sqrt(2.0));
    }

    // Densit� de probabilit� normale
    double norm_pdf(double x) const {
        return (1.0 / std::sqrt(2.0 * M_PI)) * std::exp(-0.5 * x * x);
    }

public:
    BlackScholesPricer(EuropeanVanillaOption* option, double asset_price,
        double interest_rate, double volatility)
        : _option(option), _S(asset_price), _r(interest_rate), _sigma(volatility) {
    }

    // Prix de l'option
    double operator()() const {
        double K = _option->_strike;
        double T = _option->getExpiry();

        // Option digitale
        if (dynamic_cast<EuropeanDigitalCallOption*>(_option)) {
            double d2 = (std::log(_S / K) + (_r - 0.5 * _sigma * _sigma) * T) / (_sigma * std::sqrt(T));
            return std::exp(-_r * T) * norm_cdf(d2);
        }
        if (dynamic_cast<EuropeanDigitalPutOption*>(_option)) {
            double d2 = (std::log(_S / K) + (_r - 0.5 * _sigma * _sigma) * T) / (_sigma * std::sqrt(T));
            return std::exp(-_r * T) * norm_cdf(-d2);
        }

        // Option vanille
        double d1 = (std::log(_S / K) + (_r + 0.5 * _sigma * _sigma) * T) / (_sigma * std::sqrt(T));
        double d2 = d1 - _sigma * std::sqrt(T);

        if (_option->GetOptionType() == EuropeanVanillaOption::optionType::Call)
            return _S * norm_cdf(d1) - K * std::exp(-_r * T) * norm_cdf(d2);
        else
            return K * std::exp(-_r * T) * norm_cdf(-d2) - _S * norm_cdf(-d1);
    }

    // Delta de l'option
    double delta() const {
        double K = _option->_strike;
        double T = _option->getExpiry();

        // Option digitale
        if (dynamic_cast<EuropeanDigitalCallOption*>(_option)) {
            double d2 = (std::log(_S / K) + (_r - 0.5 * _sigma * _sigma) * T) / (_sigma * std::sqrt(T));
            return std::exp(-_r * T) * norm_pdf(d2) / (_S * _sigma * std::sqrt(T));
        }
        if (dynamic_cast<EuropeanDigitalPutOption*>(_option)) {
            double d2 = (std::log(_S / K) + (_r - 0.5 * _sigma * _sigma) * T) / (_sigma * std::sqrt(T));
            return -std::exp(-_r * T) * norm_pdf(d2) / (_S * _sigma * std::sqrt(T));
        }

        // Option vanille
        double d1 = (std::log(_S / K) + (_r + 0.5 * _sigma * _sigma) * T) / (_sigma * std::sqrt(T));
        if (_option->GetOptionType() == EuropeanVanillaOption::optionType::Call)
            return norm_cdf(d1);
        else
            return norm_cdf(d1) - 1.0;
    }
};